TOKEN = "6270094781:AAHaK-D3lgZ3xghamoywjMivFSHVOu38KaU"

keys = {
    'евро': 'EUR',
    'доллар': 'USD',
    'рубль': 'RUB',
}